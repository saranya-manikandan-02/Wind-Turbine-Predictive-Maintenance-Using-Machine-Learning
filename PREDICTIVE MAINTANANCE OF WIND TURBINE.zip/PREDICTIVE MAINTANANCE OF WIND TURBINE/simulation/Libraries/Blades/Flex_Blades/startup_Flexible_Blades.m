load ss_cantilever_pva
Flexible_Cantilever_Lumped_Parameters
Flex_Blades_Params

Wind_Turbine_Flexible_Blades

% Copyright 2009-2023 The MathWorks(TM), Inc.
